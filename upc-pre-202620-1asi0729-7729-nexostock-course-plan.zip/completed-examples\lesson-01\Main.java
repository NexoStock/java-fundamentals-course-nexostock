public class Main {
    public static void main(String[] args) {
        System.out.println("Hola, mundo!");
        System.out.println("Me llamo Alex y estoy aprendiendo Java.");

    }
}
